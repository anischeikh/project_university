#ifndef _LISTES_H
#define _LISTES_H

#include "arbres.h"

typedef struct liste liste_t;
/* Type de liste à compléter selon votre besoin. */

typedef char* string;

struct cellule {
	string val;
    noeud* noeud_ptr;   //pour qu'un liste chainée puisse servir de file dans un parcours en largeur
    int entier;     //permet de stocker la profondeur des noeuds dans un parcours en largeur
	struct cellule* suivant;
};

typedef struct cellule cellule_t;

struct liste {
	cellule_t *tete;
	cellule_t *queue;
};

typedef struct liste liste_t;

/* cree une nouvelle liste, initialement vide */
void init_liste_vide(liste_t* L);

/* libère toutes les cellules de la liste */
void liberer_liste(liste_t *L);

/* Ajouter une nouvelle cellule contenant c
 * en tête de la liste L.
 * Si l'ajout est réussi, le résultat est 0,
 * et 1 sinon (échec de l'ajout)
 */
int ajouter_tete(liste_t *L, string c);

cellule_t* nouvelleCellule (void);

void enfiler_noeud(liste_t *L, noeud *n_ptr);

noeud* defiler_noeud(liste_t *L);

void enfiler_int(liste_t *L, int x);

int defiler_int(liste_t *L);

#endif /* _LISTES_H */


