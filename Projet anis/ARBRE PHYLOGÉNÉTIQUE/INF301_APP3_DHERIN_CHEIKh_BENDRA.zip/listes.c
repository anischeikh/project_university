#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "arbres.h"
#include "listes.h"

/* fichier à compléter au besoin */

void init_liste_vide(liste_t* L) {
    //printf ("<<<<< À faire: fonction init_liste_vide fichier " __FILE__ "\n >>>>>");
    /* a completer */
    //L->tete = malloc(sizeof(cellule_t));
    L->tete = NULL;
}

void liberer_liste(liste_t* L) {
    //printf ("<<<<< À faire: fonction liberer_liste fichier " __FILE__ "\n >>>>>");
    /* a completer */
    cellule_t *p;
    while (L->tete != NULL) {
        p = L->tete;
        L->tete = L->tete->suivant;
        //free(p->val);
        free(p);
    }
    //free(L);
}

cellule_t* nouvelleCellule (void)
{
    cellule_t* cel = malloc(sizeof(cellule_t));
    return cel;
}

int ajouter_tete(liste_t* L, string c) { /* retourne 0 si OK, 1 sinon  */
    //printf ("<<<<< À faire: fonction ajouter_tete fichier " __FILE__ " >>>>>\n");
    /* a completer */
    cellule_t *cel = nouvelleCellule();
    //cellule_t *p = L->tete->suivant;
    //cel->val = malloc(sizeof(cel->val));
    cel->val = c;
    cel->suivant = L->tete;
    L->tete = cel;
    //cel->suivant = p;
    if (L->tete->val == c) {
        return 0;
    }
    return 1;
}


void enfiler_noeud(liste_t *L, noeud *n_ptr) {
    assert(n_ptr);
    //cellule_t *s = L->queue->suivant;
    cellule_t* cel = nouvelleCellule();
    cel->noeud_ptr = n_ptr;
    if (L->tete == NULL) {
        cel->suivant = L->tete;
        L->tete = cel;
        L->queue = L->tete; //on initialise la queue quand la liste est vide
        return;
    }
    cel->suivant = NULL;
    L->queue->suivant = cel;
    L->queue = cel;


}

noeud* defiler_noeud(liste_t *L) {
    cellule_t *cel = L->tete; //= nouvelleCellule();
    noeud *n = L->tete->noeud_ptr;
    L->tete = L->tete->suivant;
    free(cel);
    return n;
}

void enfiler_int(liste_t *L, int x) {
    cellule_t* cel = nouvelleCellule();
    cel->entier = x;
    if (L->tete == NULL) {
        cel->suivant = L->tete;
        L->tete = cel;
        L->queue = L->tete; //on initialise la queue quand la liste est vide
        return;
    }
    cel->suivant = NULL;
    L->queue->suivant = cel;
    L->queue = cel;
}

int defiler_int(liste_t *L) {
    cellule_t *cel = L->tete; //nouvelleCellule();
    int x = L->tete->entier;
    L->tete = L->tete->suivant;
    free(cel);
    return x;
}
