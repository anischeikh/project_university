#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "arbres.h"
#include "arbresphylo.h"
#include "listes.h"

int analyse_arbre_rec(arbre a, int *nb_esp) {
    if (a == NULL) { return 0; }
    if (a->gauche == NULL && a->droit == NULL) {
        (*nb_esp)++; return 0;
    }
    return 1 + analyse_arbre_rec(a->gauche, nb_esp) + analyse_arbre_rec(a->droit, nb_esp);
}

void analyse_arbre (arbre racine, int* nb_esp, int* nb_carac)
{
    assert(nb_esp); assert(nb_carac);
    *nb_esp = 0;
    *nb_carac = analyse_arbre_rec(racine, nb_esp);

    //printf ("<<<<< À faire: fonction analyse_arbre fichier " __FILE__ "\n >>>>>");
}


/* ACTE II */
/* Recherche l'espece dans l'arbre. Modifie la liste passée en paramètre pour y mettre les
 * caractéristiques. Retourne 0 si l'espèce a été retrouvée, 1 sinon.
 */
int rechercher_espece (arbre racine, char *espece, liste_t* seq)
{
    /* à compléter */
    if (racine == NULL) { return 1; }

    if (strcmp(racine->valeur, espece) == 0) { return 0; }

    int g = rechercher_espece(racine->gauche, espece, seq);
    int d = rechercher_espece(racine->droit, espece, seq);

    if (g == 0) { return 0; }
    if (d == 0) { ajouter_tete(seq, racine->valeur); return 0; }

    return 1; 
}



/* Doit renvoyer 0 si l'espece a bien ete ajoutee, 1 sinon, et ecrire un 
 * message d'erreur.
 */
int ajouter_espece_rec (arbre* a, char *espece, cellule_t* seq) {
    /* seq == NULL revient à vérifier si on a "consommé" (pas réellment mais avec les appels récursifs) la liste de caractéristiques, autrement dit on sait quand on doit insérer l'espèce */

    /* #### cas de base, ici on ajoute toujours à droite (l'espèce a bien les caractéristiques) */
    if (*a == NULL) {
        if (seq == NULL) {  // fin liste caractères, c'est le moment d'insérer l'espèce en tant que feuille
            (*a) = nouveau_noeud();
            (*a)->valeur = strdup(espece);
            return 0;
        }
        (*a) = nouveau_noeud(); 
        (*a)->valeur = strdup(seq->val);

        return ajouter_espece_rec(&((*a)->droit), espece, seq->suivant);    //on continue à droite (car arbre vide à l'origine)
    }

    if ((*a)->gauche == NULL && (*a)->droit == NULL) {
        /* #### cas où la racine est une espèce */
        if (seq != NULL ) {
            noeud* n = nouveau_noeud(); // noeud temporaire qui deviendra la racine
            n->valeur = strdup(seq->val);
            n->gauche = nouveau_noeud();    // on prépare un noeud pour y mettre l'espèce qu'on ne veut pas perdre
            n->gauche = *a;
            *a = n;     //n devient la racine
            return ajouter_espece_rec(&((*a)->droit), espece, seq->suivant);    // on avait seulement une espèce en racine, donc on peut se permettre de tout mettre à droite
        } else {
            /* #### espèce avec même caracatères déjà présente -> impossible (liste carac écoulée mais pourtant on tombe sur une espèce (feuille)) */
            printf("Ne peut ajouter \"%s\" : possède les mêmes caractères que %s.\n", espece, (*a)->valeur);
            return 1;
        }
    }
    /* #### autrement on choisit de parcourir à gauche ou à droite en fonction de caractéristiques */
    if (seq != NULL && strcmp((*a)->valeur, seq->val) == 0) {
        return ajouter_espece_rec(&((*a)->droit), espece, seq->suivant);
    }
    else {
        return ajouter_espece_rec(&((*a)->gauche), espece, seq);    // mettre seq et non pas seq->suivant -> on ne "consomme" (appels récursifs) pas la liste de caractéristiques en allant à gauche
    }
    return 1;
}

int ajouter_espece (arbre* a, char *espece, cellule_t* seq) {
    assert(a);
    return ajouter_espece_rec(a, espece, seq);
}

/* Doit afficher la liste des caractéristiques niveau par niveau, de gauche
 * à droite, dans le fichier fout.
 * Appeler la fonction avec fout=stdin pour afficher sur la sortie standard.
 */
void afficher_par_niveau (arbre racine, FILE* fout) {
    //printf ("<<<<< À faire: fonction afficher_par_niveau fichier " __FILE__ "\n >>>>>");
    if (racine == NULL) { return; } //arbre vide
    liste_t l, l_prof;
    noeud* n;
    int prof, prof_suiv = 1;

    init_liste_vide(&l);
    init_liste_vide(&l_prof);   //liste qui stocke pour chaque noeud sa profondeur dans l'arbre

    enfiler_noeud(&l, racine);
    enfiler_int(&l_prof, 1);

    while (l.tete != NULL) {
        n = defiler_noeud(&l);
        prof = defiler_int(&l_prof);

        if (prof != prof_suiv) {
            fprintf(fout, "\n");    //vérifie si on passe au niveau suivant
            prof_suiv = prof;
        }

        fprintf(fout, "%s ", n->valeur); 

        if (n->gauche != NULL && (n->gauche->gauche != NULL || n->gauche->droit != NULL)) {     //arbre gauche existe et n'est pas une feuille (donc il est carac)
            enfiler_noeud(&l, n->gauche);
            enfiler_int(&l_prof, prof + 1);     //profondeur fils = (profondeur noeud courant) + 1
        }
        if (n->droit != NULL && (n->droit->gauche != NULL || n->droit->droit != NULL)) {
            enfiler_noeud(&l, n->droit);
            enfiler_int(&l_prof, prof + 1);

        }
    }

    liberer_liste(&l);
    liberer_liste(&l_prof);
}

// Acte 4


int ajouter_carac_rec(arbre* a, char* carac, cellule_t* seq, arbre** pred_lkca, arbre** lkca) {
    //printf ("<<<<< À faire: fonction ajouter_carac fichier " __FILE__ "\n >>>>>");

    if (*a == NULL) { return 0; }   //pour toujours avoir deux valeurs de retour pour g et d même quand l'un des fils est 'NULL'

    if ((*a)->gauche == NULL && (*a)->droit == NULL) {
        // comparaison espèce par espèce avec la feuille courante
        while (seq != NULL) {
            if (strcmp((*a)->valeur, seq->val) == 0) {
                return 1;
            }
            seq = seq->suivant;
        }
        return 0;   
    }

    int g = 0, d = 0;

    g = ajouter_carac_rec(&((*a)->gauche), carac, seq, pred_lkca, lkca);
    d = ajouter_carac_rec(&((*a)->droit), carac, seq, pred_lkca, lkca);


    /*
     *  0,0 -> 0
     *  1,1 -> 1
     *  2,2 -> 0
     *  0,1 / 1,0 -> 2
     *  2,0 / 0,2 -> 2
     *  1,2 / 2,1 -> 0
     *
     *  1 au niveau d'une caractéristique est une certitude que l'ajout est possible
     *  2 signifie que le sous arbre contient des 0 (donc des espèces non présentes), peut être validé ou invalidé à chaque noeud en remontant
     *  0 signifie que le sous arbre n'est pas accepté, il peut tout de même renvoyer une valeur "possible" au niveau de son parent si l'autre fils est possible
     */

    /* ### les deux sous arbres contiennent excluisvement des espèces voulues */
    if (g == 1 && d == 1) { 
        *pred_lkca = a;
        return 1;

        /* ### on arrive à un noeud ou seul un des deux sous arbres est "accepté" (espèces voulues) */
    } else if ((g == 0 && d == 1) || (g == 1 && d == 0)) {

        // ici on obtient 0 via un noeud non existant, on choisi de "l'accepter" dans ce cas précis
        if (d == 0 && (*a)->droit == NULL) { return 1; }
        if (g == 0 && (*a)->gauche == NULL) { return 1; }

        *pred_lkca = a; //noeud courant devient prédecésseur du plus haut noeud commun
        // 'lkca' est le fils gauche ou droit, à savoir le plus haut noeud commun
        if (d == 1) {
            *lkca = &(**pred_lkca)->droit;
        } else {
            *lkca = &(**pred_lkca)->gauche;
        }
        return 2;

        /* ### l'ajout de 'carac' est possible, on a déjà 'pred_lkca' et 'lkca', pas besoin de les modifier*/
    } else if ((g == 2 && d == 0) || (g == 0 && d == 2)) {
        return 2;
    }

    return 0;
}

int ajouter_carac(arbre *a, char *carac, cellule_t *seq) {
    if (*a == NULL) {   //arbre vide 
        printf("Ne peut ajouter \"%s\" : ne forme pas un sous-arbre.\n", carac); 
        return 0; 
    }

    arbre *pred_lkca = NULL;
    arbre *lkca = NULL;

    int possible = ajouter_carac_rec(a, carac, seq, &pred_lkca, &lkca);

    if (possible != 0) {    //si l'ajout est possible, on a 1 ou 2 donc 1
        noeud *n = nouveau_noeud();
        n->valeur = strdup(carac);

        /* ### 'pred_lkca' n'est pas défini (cas où ma valeur de retour la plus haute est 2 en passant seulement par 1,0 ou 0,1 mais un des fils est NULL) */
        if (pred_lkca == NULL) {
            n->droit = *a;  //donc 'carac' doit être la racine
            *a = n;
            return possible != 0;
        }
        /* ### ('pred_lkca' est la racine) OU (l'arbre est une feuille) -> 'carac' doit devenir la racine */
        if (*pred_lkca == *a || ((*a)->gauche == NULL && (*a)->droit == NULL)) {
            /* ### comme pour 'pred_lkca' ,  'lkca' peut être non défini en passant par un certain chemin, si il l'est, on fait une insertion plus générale (code plus bas) */
            if (lkca == NULL) {
                n->droit = *a;
                *a = n;
                return possible != 0;
            }
        }
        /* ### sinon insertion plus généraliste, 'n' est soit à gauche ou a droite de 'pred_lkca', 'lkca' est forcément à droite de 'n' */
        n->droit = *lkca;
        if ((*pred_lkca)->droit == *lkca) {
            (*pred_lkca)->droit = n;
        } else {
            (*pred_lkca)->gauche = n;
        }

    } else {
        printf("Ne peut ajouter \"%s\" : ne forme pas un sous-arbre.\n", carac);
    }
    return possible != 0;
}

arbre tab2arbre(FILE* f_tab) {
    printf("\033[0;31m ----- ACTE 5 INACHEVE -----\033[0m\n");
    // char caracs[10000];
    // char esps[10000];
    // int nb_carac = 0;
    // int nb_esp = 0;
    // int possede;
    // fscanf(f_tab, "\n");
    // fscanf(f_tab, "%d", &nb_carac);
    // fscanf(f_tab, "%d", &nb_esp);
    // fgets(caracs, 10000, f_tab);
    // fgets(esps, 10000, f_tab);
    
    // int tab[nb_esp][nb_carac];
    // for (int i = 0; i < nb_carac; i++) {
    //     for (int j = 0; j < nb_esp; j++) {
    //         fscanf(f_tab, "%d", &possede);
    //         tab[i][j] = possede;
    //     }
    // }
    // return nouveau_noeud();
    return NULL;
}
