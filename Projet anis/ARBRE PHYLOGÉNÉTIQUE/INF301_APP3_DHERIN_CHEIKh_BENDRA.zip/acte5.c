#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "arbres.h"
#include "arbresphylo.h"
#include "common_tests.h"

int verif_arbre(arbre a1, arbre a2) {
    if (a1 == NULL && a2 == NULL) {
        return 0;
    }
    
    if ((a1->gauche == NULL && a2->gauche != NULL) || (a1->gauche == NULL && a2->gauche != NULL)) {
        fprintf(stderr, "\033[0;31mERREUR\033[0m: %s est censé être une espèce et non pas une caractéristique\n", a1->valeur);
    }

    if (strcmp(a1->valeur, a2->valeur) != 0) {
        fprintf(stderr, "\033[0;31mERREUR\033[0m: on attendait %s mais on a trouvé %s\n", a1->valeur, a2->valeur);
        return 1;
    } else {
        printf("%s \033[0;32mOK\033[0m\n", a1->valeur);
    }

    int g = verif_arbre(a1->gauche, a2->gauche);
    int d = verif_arbre(a1->droit, a2->droit);

    if (!g && !d) {
        return 0;
    }
    return 1;
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage : %s <nom fichier test>\n", argv[0]);
        return 1;
    }
    char* f_test = argv[1];
    FILE* f = fopen(f_test, "r");
    if (f == NULL) {
        printf("Erreur, fichier test %s inexistant\n", f_test);
        return 1;
    }
    // char f_arbre[sizeof("tests/") + sizeof((string)f_test)];
    //     strcat(f_arbre, "tests/");
    //     strcat(f_arbre, f_test);
    char f_arbre[256];
    fscanf(f, "%s", f_arbre);
    FILE* f_a = fopen(f_arbre, "r");
    if (f_a == NULL) {
        printf("Erreur, fichier arbre %s inexistant\n", f_arbre);
        return 1;
    }

    arbre a1 = lire_arbre(f_a);
    arbre a2 = tab2arbre(f);

    int nb_carac1, nb_esp1;
    int nb_carac2, nb_esp2;
    analyse_arbre(a1, &nb_esp1, &nb_carac1);
    analyse_arbre(a2, &nb_esp2, &nb_carac2);

    if (nb_esp1 == nb_esp2 && nb_carac1 == nb_carac2){
        printf("Nombre espèces et caractéristiques pour %s\033[0;32m OK\033[0m\n", f_test);
    }
    if (nb_carac1 != nb_carac2) {
        fprintf(stderr, "\033[0;31mERREUR\033[0m pour le fichier %s, nombre de caractéristiques obtenu = %d mais on attendait %d\n", f_test, nb_carac2, nb_carac1);
        return 1;
    }
    if (nb_esp1 != nb_esp2) {
        fprintf(stderr, "\033[0;31mERREUR\033[0m pour le fichier %s, nombre d'espèces obtenu = %d mais on attendait %d\n", f_test, nb_esp2, nb_esp1);
        return 1;
    }

    return verif_arbre(a1, a2); 
}
