#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "client.h"
#define MAXMSG MAXREP
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include "client.h"

#define MAXMSG MAXREP


void concat(char *d,  char *s) {
    int l= strlen(d);
    int i;

    for (i = 0; s[i] != '\0'; i++) {
        d[l+ i] = s[i];
    }

    d[l+ i] = '\0';
}

void InverseSiXsuperieureAlaTaille(int z,int l,char *txt) {
    z=l;

    while(z>=0) {
        txt[z+1] = txt[z];
        z--;
    }

}


void copieV2(char *dest, char*src) {
    int i = 0;
    dest=dest+1;
    
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    
    dest[i] = '\0';
    
}

void copieV1(char *c, char *txt, int l, int x) {
    int i;

    int z = l - x;

    for (i = 0; i < x; i++) {
        c[i] = txt[z + i];
    }

    c[i] = '\0';
    txt[z] = '\0';
}

void Deplacement(int l,int x,char *txt,char *c) { 
            copieV1(c, txt,l,x);
            concat(c, txt);
            copieV2(txt, c);

}

void decr(char * enc, char * txt) {
    char c[MAXMSG]; 
    int l,  x,z=0;
    l= 0;
    
    for(int e = strlen(enc)-1;e>=0;e--) {
        x = enc[e] % 8;
        
        if (l< x) {
            InverseSiXsuperieureAlaTaille(z,l,txt);
            l++;  
            txt[0] = enc[e]; 
        } else {
            Deplacement(l,x,txt,c); 
            l++;
            txt[0] = enc[e];
        }
    }
    txt[l] = '\0';
}

//cette fonction permet de rechercher l indice du  caractere
int RechercheI(char *s, char charr) {
    int l = strlen(s);
    for (int i = 0; i < l;i++) {
        if (s[i] == charr) {
            return i;
        }
    }
    return -1;
}

//cette fonction permet de faire le decalage de la sequence a gauche
void gauche(char *s, int d) {
    int l = strlen(s);
        for (int i = d + 1; i < l; i++) {
        s[i - 1] = s[i];
    }
}

//cette fonction permet d ajouter le caractere a la fin de la sequence
void ajouter(char *s, char charr) {
    int l = strlen(s);
    s[l] = charr;
    s[l+ 1] = '\0';
}

//cette fonction permet de retourner le caractere d avant 
char charAvant(char *s, int i) {
    if (i == 0) {
        return s[strlen(s) - 1];
    }
    return s[i - 1];
}

void encryptSequence(char *message, char *enc) {
    char s[MAXMSG] = "";
    int i = 0;

    while (message[i] != '\0') {
        int f = RechercheI(s, message[i]);

        if (f!=-1) {// Verifie si la sequence n est pas vide
            char temp= s[f];
            enc[i] = charAvant(s, f);
            
            if ((size_t)f < strlen(s) - 1) {
                gauche(s, f);
                s[strlen(s) - 1] = temp;
            }
            
        } else  {
            enc[i] = message[i];
            ajouter(s, message[i]);
        }
        i++;
    }
    enc[i] = '\0';
}

int main() {
    // Affiche les échanges avec le serveur (false pour désactiver)
    mode_debug(true);
    char reponse[MAXREP],SEQ[MAXREP],msg[MAXREP];


    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 443);

    // Remplacez <identifiant> et <mot mde passe> ci dessous.
    envoyer_recevoir("login 12202656 \"D'HERIN\"",reponse);
    
    envoyer_recevoir("load crypteSeq",reponse);
    
    envoyer_recevoir("Alice, nous avons besoin de toi. Decode mon message au plus vite. Bob",reponse); 
    envoyer_recevoir("start",reponse);
   
    decr(reponse,SEQ);
    
    encryptSequence(SEQ,msg);
    envoyer_recevoir(msg,reponse);
}