#include "client.c"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#define MAXMSG MAXREP


//fonction pour appliquer le decalage de cesar
void transf(char*rep,int dec){
           int i=0;
// au lieu d utiliser %26 pour qu c soit circulaire et reste dans l alphabet on peut faire
//la lettre -26 si il sort de z sinon +26 si il sort de a la on gere ce cas

    while(rep[i]!='\0'){
        if (rep[i]>='a'+dec && rep[i]<='z'){
                rep[i]=rep[i]-dec;}
            else if(rep[i]<'a'+dec && rep[i]>='a'){
                rep[i]=rep[i]+26-dec;  
            }
        
         if(rep[i]>='A'+dec && rep[i]<='Z'){
                rep[i]=rep[i]-dec;
            }
             else if(rep[i]<'A'+dec && rep[i]>='A'){
                rep[i]=rep[i]+26-dec;  
            }
            
        i=i+1;
    }

}
int main() {
    
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    // char message[MAXMSG];
    char mdp[60]="hasta la revolucion"; 
    //char rep[MAXREP]; // pour stocker le message à envoyer au serveur
   
    
    
    mode_debug(true);
    
    connexion("im2ag-appolab.u-ga.fr", 9999);
    envoyer_recevoir("login 12202656 \"D'HERIN\"", reponse);
    envoyer_recevoir("load planB", reponse);
    envoyer_recevoir("ok",reponse);
    envoyer_recevoir("start",reponse);
    envoyer_recevoir("aide",reponse);
        //on calcule le decalge on sait que notre message va commence par Chere donc on prend le premier caractere de notre message-C
        
    int dec=reponse[0]-'C'; 
    transf(mdp,dec);
    envoyer_recevoir(mdp,reponse);
    transf(reponse,dec);
    envoyer_recevoir(reponse,reponse);
 
    

    return 0;
}