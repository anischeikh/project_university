#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"

void deplace(char* msg, int x) {
    int i = 0;
    unsigned long j = 0;
    char tmp;
    while (i < x) {
        j = 0;
        while (j < (strlen(msg)-1)) {
            tmp = msg[j + 1];
            msg[j + 1] = msg[j];
            msg[j] = tmp;
            j++;
        }
        i++;
    }
}

void del_first_char(char* msg){
    char *buff=malloc(strlen(msg));
    for (unsigned long i = 0; i < strlen(msg)-1; i++)
    {
        buff[i] = msg[i + 1];
    }
    strcpy(msg, buff);
}

void chiffrement(char* msg) {
    char *buff = malloc(strlen(msg));
    char c;
    int i=0;
    unsigned long x;
    //for (unsigned long i=0; i < strlen(msg); i++)
     while(strlen(msg) != 0) {
        // printf("%c\n",msg[i]);
        c = msg[0];
        x = c % 8;
        msg[i] = c;
        i++;
        del_first_char(msg);
        if(x > strlen(msg)) { 
            x = strlen(msg);
        }
        deplace(msg, x);
    }
    strcpy(msg,buff);
}

int main() {
    mode_debug(true);
    char reponse[MAXREP]; // pour stocker la réponse du serveur
    char message[MAXREP];
    connexion("im2ag-appolab.u-ga.fr", 9999);

    envoyer_recevoir("login 12202656 \"D'HERIN\"", reponse);
    envoyer_recevoir("load crypteMove", reponse);
    envoyer_recevoir("help", reponse);
    
    //char TXT[]="Petit message court.";
    //char ENC[strlen(TXT)];
    //char C;
    //printf("%s\n", reponse);
    //char TXT = message;
    strcpy(message, reponse);
    chiffrement(message);
    
    //printf("%s\n", TXT);

    //printf("%s\n", reponse);
    //strcpy(message,reponse);
    // printf("%s\n",deplace(TXT,7));
    envoyer_recevoir("start", reponse);
    envoyer_recevoir(message, reponse);
    printf("%s\n",reponse);
    //printf("%s\n", TXT);
    //printf("%s",move_file(fich));
    //envoyer_recevoir(move_file("msg-crypteMove.txt"), reponse);

}