#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include "client.c"
#include "client.h"


#define MAXMSG MAXREP



void InverseSiXsuperieureAlaTaille(int z,int l,char *txt)
           {z=l;
            while(z>=0)
          
          {
          txt[z+1] = txt[z];

           z--;
           }

            }

void copie(char *dest, char*src) {
    int i = 0;
    
    // Copie chaque caractère de src dans dest jusqu'à atteindre '\0' (fin de la chaîne)
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    
   
    dest[i] = '\0';
}
void copieV2(char *dest, char*src) {
    int i = 0;
    dest=dest+1;
    
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    

    dest[i] = '\0';
    
}
void copieV1(char *c, char *txt, int l, int x) {
    int i;

    
    int z = l - x;

    
    for (i = 0; i < x; i++) {
        c[i] = txt[z + i];
    }

    
    c[i] = '\0';
    txt[z] = '\0';
}
void Deplacement(int l,int x,char *txt,char *c)   
        { 
            copieV1(c, txt,l,x);
            strcat(c, txt);
            copieV2(txt, c);

        }  

           
void decr(char * enc, char * txt) {
    char c[MAXMSG]; 
    int l,  x,z=0;
    l= 0;
    
    for(int e = strlen(enc)-1;e>=0;e--)
    {
        x = enc[e] % 8;
        
        if (l< x) {
          InverseSiXsuperieureAlaTaille(z,l,txt);
         l++;  
         txt[0] = enc[e]; 
        } else {
            
            Deplacement(l,x,txt,c); 
            l++;
            txt[0] = enc[e];
            }
    }
    txt[l] = '\0';
}

void DeplacXpremier(int j,int x,char *txt,char *c) { 
    j=0;
    while (j<=x-1) {
        c[j] = txt[j+1];
        j++;
    }
    c[x] = '\0';

}  

void RemplaceTextXpremierChar(int k,int x ,int l,char *txt) {
    k=x+1;
    while(k<=l) {
        txt[k-x-1] = txt[k];
        k++;
    }
}

void SiXsuperieureAlaTaille(int z,int l,char *txt) {
    z=0;
    while(z<=l) {
        txt[z] = txt[z+1];
        z++;
    }

}

void encr(char * txt, char * enc) {
    char c[MAXREP]; 
    
    int z=0,j=0,i,x,k=0;
      
    i=0;
    

    for (int l= strlen(txt);l>0;l--)
     {
        
        x = txt[0] % 8;
        enc[i] = txt[0];

        
        
        if (l<= x) {
        SiXsuperieureAlaTaille (z,l,txt);
            
        } else {
        DeplacXpremier(j,x,txt,c);
        RemplaceTextXpremierChar(k,x,l,txt);
        strcat(txt,c);
        
        }
        i++;
    }

    enc[i] = '\0';
}



int main() {
    char reponse[MAXREP];
    char message[MAXREP];
    
    // pour stocker la réponse du serveur
    
// pour stocker le message à envoyer au serveur

    // Affiche les échanges avec le serveur (false pour désactiver)
    

    // Connexion au serveur AppoLab
connexion("im2ag-appolab.u-ga.fr", 9999);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
envoyer_recevoir("login 12315436 CHEIKH",reponse);

envoyer_recevoir("load BayOfPigs", reponse);

envoyer_recevoir("start",reponse);


decr(reponse,message);
printf("%s",message);

char enc[MAXREP] ="Patria o muerte";

encr(enc,message);

printf("\n%s",message);

envoyer_recevoir(message,reponse);


envoyer_recevoir("alors",reponse);
printf("\n%s",reponse);









}