#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>
#include "client.h"

#define MAXMSG MAXREP


char* Cesar(char* msg, int c) {
    for(int i=0; msg[i]!='\0'; i++) {
        if ('a' <= msg[i] && 'z' >= msg[i]){    //decode minuscules
            msg[i] = (msg[i] - 'a' - c) % 26 + 'a';
            if (msg[i]==92)//traitement des cas partucliers
            msg[i]='v';

            if (msg[i]==94)
            msg[i]='x';

            if (msg[i]==95)
            msg[i]='y';
             //code ascii du char de msg - 'a' pour qu'on se place dans un repère où a = 0 et z = 25, ensuite on ajoute le décalage, on le restreint aux lettres de l'alphabet avec le % 26,
            //puis on réajoute 'a' pour revenir au code ascii correspondant
        }
        if ('A' <= msg[i] && 'Z' >= msg[i]){    //decode majuscules
            msg[i] = (msg[i] - 'A' - c ) % 26 + 'A';
        }
        if (msg[i]==62)//traitement des cas partucliers
        msg[i]='X';
    }
    return msg;
}


int main() {
    char reponse[MAXREP];

    // Connexion au serveur AppoLab
    connexion("im2ag-appolab.u-ga.fr", 9999);
    // utilisez le port 443 en cas de problème sur le 9999
    /* connexion("im2ag-appolab.u-ga.fr", 443); */

    // Remplacez <identifiant> et <mot de passe> ci dessous.
    envoyer_recevoir("login 12315436 CHEIKH",reponse);
    envoyer_recevoir("load projetX", reponse);
    envoyer_recevoir("start", reponse);
    envoyer_recevoir("help", reponse);


    printf("\n %s",Cesar(reponse,5));









}
