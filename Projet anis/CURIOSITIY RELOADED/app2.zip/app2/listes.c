#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>
#ifdef NCURSES
#include <ncurses.h>
#endif
#include "listes.h"


/*
 *  Auteur(s) :
 *  Date :
 *  Suivi des Modifications :
 *
 */

bool silent_mode =false;


cellule_t* nouvelleCellule (void)
{
    /* À compléter (utiliser malloc) */
    cellule_t* cel;
    cel = malloc(sizeof(cellule_t));

    return cel;
}



void detruireCellule (cellule_t* cel)
{
    /* À compléter (utiliser free) */
    free(cel);
}

void add_head(sequence_t* sequence, char new_command) {
    
    cellule_t* new = (cellule_t*)malloc(sizeof(cellule_t));
    new->command = new_command;
    new->suivant = sequence->tete;
    sequence->tete = new;
}

void add_end(sequence_t *seq, char car) {
 
  cellule_t *q=seq->tete;
  
  if (q== NULL){
      add_head(seq,car);
      return;
  }
   cellule_t *p=malloc(sizeof(cellule_t));
  while(q->suivant != NULL){
      q = q->suivant;
  }
  p->command = car;
  p->suivant = NULL;
  q->suivant = p;
  return;
}



void conversion (char *texte, sequence_t *seq)
{
    /* À compléter */
    cellule_t *tab = nouvelleCellule();
    seq->tete = tab;
    tab->command = texte[0];
    cellule_t *p = seq->tete;
    
    int i = 1;
    while(texte[i] != '\0') {
        tab = nouvelleCellule();
        tab->command = texte[i];
        p->suivant = tab;
        p = tab;
        i++;
    }
    p->suivant = NULL;
    //printf("\n>>>>>>>>>>> A Faire : liste.c/conversion() <<<<<<<<<<<<<<<<\n");
}






void afficher (sequence_t* seq)
{
    if (seq!=NULL)
   { cellule_t *cel;
    cel = seq->tete;
    while(cel != NULL){
    printf("%c", cel->command);
        cel = cel->suivant;
    }
    printf("\n");
   }
   else {
    printf("liste vide");
   }
}


void fvn(pile *p, cellule_t *q){
    
    if (p->n >=3)
    {
    cellule_t *buffer =q->suivant;
    sequence_t p1;
    type f = depiler(p);
    type v = depiler(p);
    type n = depiler(p);
    p1 = (n.val == 0) ? f.car : v.car;
    q->suivant = p1.tete;
    while (q->suivant != NULL){
        q = q->suivant;
    }
    q->suivant = buffer;
    }
    else {
        printf("pile doit contenir 3 elements min");
        return ;
    }
}






void exclamation(pile *pila, cellule_t *c) {
    type fv = depiler(pila);

    // Initialisation de la séquence de copie
    sequence_t cp;
    cp.tete = nouvelleCellule();

    // Pointeurs pour parcourir les cellules des deux séquences
    cellule_t* c1 = fv.car.tete;
    cellule_t* c2 = cp.tete;

    // Copie du contenu de la séquence source vers la séquence de copie
    while (c1 != NULL) {
        
        c2->suivant = nouvelleCellule();

        
        c2->suivant->command = c1->command;

    
        c1 = c1->suivant;
        c2 = c2->suivant;
    }

    // Fixation du suivant de la dernière cellule de copie à NULL
    if (c2 != NULL) {
        c2->suivant = NULL;
    }

    // Insérer la séquence copiée après la cellule 'c'
    cellule_t* temp = c->suivant;
    c->suivant = cp.tete;

    // Parcourir jusqu'à la fin de la séquence insérée
    while (c->suivant != NULL) {
        c = c->suivant;
    }

    // Relier la fin de la séquence copiée à la suite de la cellule temp
    c->suivant = temp;
}




void empiler(pile *p, type x)
{
   
        p->tab[p->n] = x;
        p->n++;
    
}

type depiler(pile *p)
{
    
        p->n--;
        return p->tab[p->n];
    
}


void add(pile *p)
{
    type x1,x2,s;
   
        x1 = depiler(p);
        x2 = depiler(p);
        s.val = x1.val+x2.val;
        empiler(p,s);
    
    
}

void sous(pile *p)
{
    type x1,x2,s;
   
        x1 = depiler(p);
        x2 = depiler(p);
        s.val = x1.val-x2.val;
        empiler(p,s);
    
    
}



void mup(pile *p)
{
    type x1,x2,s;
   
        x1 = depiler(p);
        x2 = depiler(p);
        s.val = x1.val*x2.val;
        empiler(p,s);
    
    
}
pile *creer_pile(pile *p)
{
  p = (pile *)malloc(sizeof(pile));
  p->n = 0;
  return p;

}





