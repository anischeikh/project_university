#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#ifdef NCURSES
#include <ncurses.h>
#endif
#include "curiosity.h"
#include "listes.h"


/*
 *  Auteur(s) :
 *  Date :
 *  Suivi des Modifications :
 *
 */

void stop (void)
{
    char valer = '\0';
    if (! silent_mode)  printf ("Appuyer sur valrée pour continuer...\n");
    while (valer != '\r' && valer != '\n') { valer = getchar(); }
}


int interprete (sequence_t* seq, bool debug)
{
    // Version temporaire a remplacer par une lecture des commandes dans la
    // liste chainee et leur interpretation.

    

   int n;

    debug = true; /* À enlever par la suite et utiliser "-d" sur la ligne de commandes */

     printf ("Programme:");
     afficher(seq);
     printf ("\n");
    if (debug) stop();

    // À partir d'ici, beaucoup de choses à modifier dans la suite.
    
    cellule_t *q = seq->tete;
    
    type x1,x2,x3,x4;
    int x5=0;
    pile *p=NULL;
    p=creer_pile(p);
    //déclaration de la pile
    
    
    sequence_t *sous_liste = malloc(sizeof(sequence_t));
    int b = 0;
   
    
    while ( q != NULL ) { //à modifier: condition de boucle
       
       char x=q->command;
        if (b > 0){
            //act 4
            if (x== '{')
              {
                b++;/* le nbr de  sous listes*/
              }
             else if (x == '}')
              {
                  (b != 1) ? (add_end(sous_liste, x), b--) : (x4.car = *sous_liste, empiler(p, x4), b = 0 /*} b=0 fin de sous-listes*/);

              } 
         add_end(sous_liste,q->command);/*ajoute en fin de de dans sous-listes*/
                 }
        else
        {
        switch (q->command)
         {
            
            
            /* Ici on avance tout le temps, à compléter pour gérer d'autres commandes */

            case 'A':
                x5= avance();
                
                if (x5== VICTOIRE) return VICTOIRE; /* on a atteint la cible */
                if (x5== RATE)     return RATE;     /* tombé dans l'eau ou sur un rocher */
                break; /* à ne jamais oublier !!! */
            case 'G':
                gauche();
                break;
            case 'D':
                droite();
                break;
                
            case '{'://debut act4
                sous_liste->tete = nouvelleCellule();/*creation de sous-liste*/
                sous_liste->tete = NULL;
                b = 1;//existance de sous-listes
                break;
             //operation act 2
            case '+':
                add(p);
                break;
            case '-':
                sous(p);
                break;
            case '*':
                mup(p);
                break;
                //debut act 3
            case 'P':
                pose(depiler(p).val);
                break;
            case 'M':
               x5= mesure(depiler(p).val);
               x4.val=x5;
                empiler(p,x4);
                break;
                //fin act3
 
            case '?'://act 4
                fvn(p, q);
                break;
            case '0'...'9':
            x=q->command;
            
            if (sscanf(&x, "%d", &n) == 1) {
            
            x4.val=n;
            empiler(p,x4);
            }break;

            case 'X':
            x1 = depiler(p);
            x2 = depiler(p);
            empiler(p, x1);
            empiler(p, x2);
            break;

            case '!':
            exclamation(p, q);
            break;


            case 'C':
            x3 = depiler(p);
            empiler(p,x3);
            empiler(p,x3);
            break;
            
          
            default:
           
            eprintf("command incorrect %c",x);
                 
          }
        }
        q = q->suivant;
        

        /* Affichage pour faciliter le debug */
      
        
        afficherCarte();
        printf ("Programme:");
         
        seq->tete = seq->tete->suivant;
        
        afficher(seq);
        printf ("%c\n",x);
        printf ("\n");
        
        if (debug) stop();
    }
   
   
    /* Si on sort de la boucle sans arriver sur la cible,
     * c'est raté :-( */

    return CIBLERATEE;
}
